#include <stdio.h>
#include <string.h>
#include "produto.h"
#include "util.h"

int buscarPorCodigo(const Produto produtos[], int total, int codigo)
{
    int i;
    for (i = 0; i < total; i++)
        if (produtos[i].codigo == codigo) return i;
    return -1;
}

int buscarPorNome(const Produto produtos[], int total, const char nome[])
{
    int i;
    for (i = 0; i < total; i++)
        if (strcmp(produtos[i].nome, nome) == 0) return i;
    return -1;
}

void exibirProduto(const Produto *produto, const Categoria categorias[], int totalCategorias)
{
    int pos = buscarCategoriaPorCodigo(categorias, totalCategorias, produto->codigoCategoria);
    printf("\n========== DADOS DO PRODUTO ==========\n");
    printf("Codigo: %d\nNome: %s\nPrateleira: %c\nPreco unitario: R$ %.2f\nQuantidade em estoque: %d\n",
           produto->codigo, produto->nome, produto->prateleira, produto->preco, produto->quantidade);
    printf("Categoria: %s\n", pos >= 0 ? categorias[pos].nome : "Categoria nao encontrada");
    printf("Disponivel para venda: %s\n======================================\n",
           produto->disponivel ? "Sim" : "Nao");
}

int cadastrarProduto(Produto produtos[], int total, const Categoria categorias[], int totalCategorias)
{
    Produto novo;
    int codigoCategoria;
    if (total >= MAX_PRODUTOS) {
        printf("\nA lista esta cheia! Limite de %d produtos.\n", MAX_PRODUTOS);
        return total;
    }
    if (totalCategorias == 0) {
        printf("\nCadastre pelo menos uma categoria antes de cadastrar um produto.\n");
        return total;
    }
    printf("\n========== CADASTRO DE PRODUTO ==========\n");
    while (1) {
        novo.codigo = lerInteiroPositivo("Digite o codigo do produto: ");
        if (buscarPorCodigo(produtos, total, novo.codigo) == -1) break;
        printf("Esse codigo ja esta cadastrado. Digite outro.\n");
    }
    lerTextoObrigatorio("Digite o nome do produto: ", novo.nome, sizeof(novo.nome));
    printf("\nCategorias disponiveis:\n");
    listarCategorias(categorias, totalCategorias);
    while (1) {
        codigoCategoria = lerInteiroPositivo("Digite o codigo da categoria do produto: ");
        if (buscarCategoriaPorCodigo(categorias, totalCategorias, codigoCategoria) >= 0) break;
        printf("Categoria inexistente. Escolha um codigo da lista.\n");
    }
    novo.codigoCategoria = codigoCategoria;
    novo.prateleira = lerPrateleira();
    novo.preco = lerPreco("Digite o preco unitario: R$ ");
    novo.quantidade = lerInteiroNaoNegativo("Digite a quantidade em estoque: ");
    novo.disponivel = novo.quantidade > 0;
    produtos[total] = novo;
    printf("\nProduto cadastrado com sucesso!\n");
    exibirProduto(&novo, categorias, totalCategorias);
    return total + 1;
}

void listarProdutos(const Produto produtos[], int total, const Categoria categorias[], int totalCategorias)
{
    int i;
    if (total == 0) {
        printf("\nNenhum produto foi cadastrado.\n");
        return;
    }
    printf("\n========== LISTA DE PRODUTOS ==========\n");
    for (i = 0; i < total; i++)
        exibirProduto(&produtos[i], categorias, totalCategorias);
}

void pesquisarProduto(const Produto produtos[], int total, const Categoria categorias[], int totalCategorias)
{
    int opcao, codigo, posicao;
    char nome[TAM_NOME_PRODUTO];
    if (total == 0) {
        printf("\nNenhum produto cadastrado para pesquisar.\n");
        return;
    }
    printf("\n========== PESQUISAR PRODUTO ==========\n1 - Por codigo\n2 - Por nome exato\n");
    do {
        opcao = lerInteiroPositivo("Escolha uma opcao: ");
        if (opcao != 1 && opcao != 2) printf("Opcao invalida. Digite 1 ou 2.\n");
    } while (opcao != 1 && opcao != 2);
    if (opcao == 1) {
        codigo = lerInteiroPositivo("Digite o codigo do produto: ");
        posicao = buscarPorCodigo(produtos, total, codigo);
        if (posicao >= 0) exibirProduto(&produtos[posicao], categorias, totalCategorias);
        else printf("\nNenhum produto encontrado com esse codigo.\n");
    } else {
        lerTextoObrigatorio("Digite o nome do produto: ", nome, sizeof(nome));
        posicao = buscarPorNome(produtos, total, nome);
        if (posicao >= 0) exibirProduto(&produtos[posicao], categorias, totalCategorias);
        else printf("\nNenhum produto encontrado com esse nome exato.\n");
    }
}
